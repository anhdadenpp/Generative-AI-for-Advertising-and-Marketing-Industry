export const handler = async (event, context) => {
  let assets = [
    {
      original: "../../assets/example-images/cocktails.jpeg",
      thumbnail: "../../assets/example-images/cocktails thumb.jpeg",
      s3ObjectKey: "",
      s3ObjectBucket: "",
    },
    {
      original: "../../assets/example-images/sushi.jpeg",
      thumbnail: "../../assets/example-images/sushi thumb.jpeg",
      s3ObjectKey: "",
      s3ObjectBucket: "",
    },
    {
      original: "../../assets/example-images/surfer.jpeg",
      thumbnail: "../../assets/example-images/surfer thumb.jpeg",
      s3ObjectKey: "",
      s3ObjectBucket: "",
    },
  ];

  return {
    success: true,
    message: "Successfully retrieved static URLs",
    result: assets,
    nextToken: " ",
  };
};
