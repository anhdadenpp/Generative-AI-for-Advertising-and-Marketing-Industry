import { LambdaClient, InvokeCommand } from "@aws-sdk/client-lambda";
import { RekognitionClient, DetectLabelsCommand } from "@aws-sdk/client-rekognition";
import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";
import { PutObjectCommand, S3Client } from "@aws-sdk/client-s3";

const s3Client = new S3Client({});

const getImageFromBedrock = async (promptText, region, preset, modelOverride='', mode = 'text-to-image',imageBase64='') => {
  const bedrockClient = new BedrockRuntimeClient({ region });
  let params = {}

  if(!modelOverride||modelOverride.length==0)
  {
    params = {
      "prompt": `${preset}-style image of ${promptText}`,
      "mode": mode,
    }
    //task 5 - pass image base64 for image-to-image mode
    if(mode=='image-to-image')
    {
      params.image = imageBase64;
      params.strength = 0.75;

    }
    else 
    {
      params.aspect_ratio = "16:9"
    }
    modelOverride = "stability.sd3-large-v1:0";
  }
  else
  {
    params = {
      "taskType": "TEXT_IMAGE",
      "textToImageParams": {
          "text": `${preset}-style image of ${promptText}`,
          "negativeText": negative_text
      },
      "imageGenerationConfig": {
          "numberOfImages": 1,
          "seed": random.randint(0, 214783647),
          "width": 1173,
          "height": 640
      }
    }
  }
  
  const bedrockInput = {
    modelId: modelOverride,
    accept:'application/json', 
    contentType:'application/json',
    body: JSON.stringify(params),
  };

  try {
    const bedrockCommand = new InvokeModelCommand(bedrockInput);
    const bedrockResponse = await bedrockClient.send(bedrockCommand);
    const jsonString = new TextDecoder("utf-8").decode(bedrockResponse.body.buffer);
    const parsedData = JSON.parse(jsonString);
    return parsedData.images[0];
  } catch (error) {
    console.error("Error in getImageFromBedrock:", error);
    return null;
  }
};

const saveImageToS3 = async (imageData,key,bucket)=>{
  const command = new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: imageData,
  });

  try {
    const response = await s3Client.send(command);
    console.log(response);
  } catch (err) {
    console.error(err);
  }
}

export const handler = async (event, context) => {
  const type = event.type;
  const metadata = event.metadata ? JSON.parse(event.metadata) : { stylePreset: "photographic" };
  const style = metadata.stylePreset || "photographic";
  const region = context.invokedFunctionArn.split(":")[3];
  let data = event.data;

  let body, imageBase64, key, modelOverride;
  modelOverride = process.env.ModelOverride

  if (type == 'use image selection' && data.includes("base64,")) {
      imageBase64 = data.split("base64,")[1];
      console.log("Existing image base64:", imageBase64);
      key = metadata.RequestorId+".png";
      body = Buffer.from(imageBase64, "base64");
      await saveImageToS3(body,key,process.env.GeneratedImagesBucket)
      data = "s3Object,"+process.env.GeneratedImagesBucket+"|"+key;
    }
  else if (type == 'generate a variation of image selection' || type == 'generate from image description') {
    if(type == 'generate a variation of image selection')
    {
      imageBase64 = data.split(';base64,')[1];
      imageBase64 = await getImageFromBedrock(data.split(';base64,')[0].replace("image_description,", ""), region, style, modelOverride, 'image-to-image',imageBase64);
    }
    else 
    {
      imageBase64 = await getImageFromBedrock(data.replace("image_description,", ""), region, style, modelOverride);
      
    }

    body = Buffer.from(imageBase64, "base64");
    imageBase64 = "base64," + imageBase64;
    key = metadata.RequestorId+".png";
    await saveImageToS3(body,key,process.env.GeneratedImagesBucket)
    data = "s3Object,"+process.env.GeneratedImagesBucket+"|"+key;
  } 
  const rekognitionClient = new RekognitionClient({ region });
  const imageParams = {
    Features: ["GENERAL_LABELS", "IMAGE_PROPERTIES"],
    Settings: { ImageProperties: { MaxDominantColors: 14 } },
    MaxLabels: 10,
    MinConfidence: 90,
    Image: {
          S3Object: {
            Bucket: data.split("s3Object,")[1].split("|")[0],
            Name: data.split("s3Object,")[1].split("|")[1],
          }
        }
  };

  const rekognitionResults = await rekognitionClient.send(new DetectLabelsCommand(imageParams));

  const payload = {
    requestorId: metadata.RequestorId,
    context: `${metadata.Context}_${style}`,
    rekognitionResults,
  };

  const lambdaClient = new LambdaClient({ region });
  const invokeCommand = new InvokeCommand({
    FunctionName: process.env.GenerateAdCopyLambda,
    InvocationType: "Event",
    Payload: JSON.stringify(payload),
    LogType: "Tail",
    ClientContext: `${metadata.RequestorId}_${metadata.Context}`,
  });

  const invokeResult = await lambdaClient.send(invokeCommand);

  const result = {
    ...event,
    metadata: JSON.stringify(rekognitionResults),
    data: imageBase64 || data,
  };

  return result;
}