import {QueryCommand, DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { unmarshall, convertToNative } from "@aws-sdk/util-dynamodb";

export const handler = async (event, context) => {
  console.log(event);
  var table = process.env.MoodboardHistoryTableName;
  const client = new DynamoDBClient({});
  const command = new QueryCommand({
    TableName: table,
    KeyConditionExpression: "part_type = :part",
    IndexName: 'part_type-generated_date-index',
    ExpressionAttributeValues: {
      ":part": { S: 'data' },
    }
  });
  
  var moodboards = [];
  const response = await client.send(command);
  console.log(response)
  for (var i = 0; i < response.Items.length; i++) {
    var newItem = unmarshall(response.Items[i]);
    moodboards.push({Id:newItem.moodboard_id,content:JSON.stringify(newItem),date_created:newItem.generated_date,prompt:newItem.prompt})
  }
  return {items: moodboards};
};
