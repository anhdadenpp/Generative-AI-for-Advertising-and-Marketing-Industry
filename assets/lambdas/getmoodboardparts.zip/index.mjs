import { QueryCommand, DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { unmarshall, convertToNative } from "@aws-sdk/util-dynamodb";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";

export const handler = async (event, context) => {
  console.log(event);
  var id = event.Id;
  var table = process.env.MoodboardHistoryTableName;
  const client = new DynamoDBClient({});
  const command = new QueryCommand({
    TableName: table,
	IndexName: 'moodboard_id-part_type-index',
    KeyConditionExpression: "moodboard_id = :moodboard_id",
    ExpressionAttributeValues: {
      ":moodboard_id": { S: id },
    },
  });
  var region = context.invokedFunctionArn.split(":")[3];

  var s3Client = new S3Client({region:region});
  var imagery = [];
  var sounds = [];
  var moodboard = {};
  const response = await client.send(command);
  for (var i = 0; i < response.Items.length; i++) {
    var newItem = unmarshall(response.Items[i]);
    switch (newItem.part_type) {
		case "google_images":
		case "imagery":
      	case "feature-image":
        {
          {
      			const s3Client = new S3Client()
      			const signCommand = new GetObjectCommand({
      			  Bucket: newItem.bucket,
      			  Key:newItem.key
			      })
      			const preSignedUrl = await getSignedUrl(s3Client, signCommand, {
      			expiresIn: 3600
      			})
      			newItem.thumbnail = preSignedUrl;
      			newItem.original = preSignedUrl;
      			newItem.loading = false;
          }
          if (newItem.part_type != 'feature-image') 
		  	imagery.push(newItem);
          else moodboard.featureImage = newItem;
        }
        break;
      case "data":
        {
          moodboard.taglines = newItem.taglines;
          moodboard.pitch = newItem.pitch;
          moodboard.fonts = newItem.fonts;
          moodboard.colors = newItem.colors;
          moodboard.adjectives = newItem.adjectives;
          moodboard.generated_date = newItem.generated_date;
          if(newItem.sounds && (!newItem.clips||newItem.clips.length==0))
          {
            if(newItem.sounds)
            {
              if(typeof(newItem.sounds)=='string'&&newItem.sounds.length>0)
                newItem.sounds=JSON.parse(newItem.sounds)
              
              for(var x = 0; x<newItem.sounds.length;x++)
              {
                var s = newItem.sounds[x];
                  sounds.push({
                  description:s.description,clips:[]
                })
              }
            }
          }
          
    		  moodboard.spec = newItem.spec;
    		  moodboard.prompt = newItem.prompt;
    		  moodboard.moodboard_id = newItem.moodboard_id;
    		  moodboard.style = newItem.style;
    		  console.log(
    			'moodboard data found',moodboard
    		  )
        }
        break;
      case "sounds": {
        var match = sounds.findIndex(s=>s.description == newItem.query);
    		var previews = JSON.parse(newItem.previews);
    		if(match==-1)
    		{
    			newItem.clips = []; 
    			newItem.description = newItem.query;
    			if(previews&&previews.length>0)
    				newItem.clips=[previews[0]];
    			sounds.push(newItem);
		    }
      }
    }
    moodboard.imagery = imagery;
    moodboard.sounds = sounds;
  }
  console.log(moodboard);
  return { Id:id,content: JSON.stringify(moodboard) };
};
