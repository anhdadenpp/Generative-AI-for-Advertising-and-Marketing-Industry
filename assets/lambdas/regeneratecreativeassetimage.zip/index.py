import json
import logging
import boto3
import botocore
import random
import uuid;
import time
import os
from io import BytesIO
import pybase64
from boto3.dynamodb.conditions import Key
from datetime import datetime, timezone, date
import base64

def image_body(imagery_type, prompt,style_preset):
    """
    Create the body for image generation based on the given parameters.
    """
    negative_prompts = [
        "ugly", "duplicate", "morbid", "mutilated", "out of frame",
        "extra fingers", "mutated hands", "poorly drawn hands", "poorly drawn face",
        "mutation", "deformed", "blurry", "bad anatomy", "bad proportions",
        "extra limbs", "cloned face", "disfigured", "gross proportions",
        "malformed limbs", "missing arms", "missing legs", "extra arms",
        "extra legs", "fused fingers", "too many fingers", "long neck", "nude"
    ]

    #Task 4 - add below
    width, height = (768, 1152) if imagery_type == "feature-image" else (768, 768)

    negative_text = ", ".join(negative_prompts)

    # Task 4 - Remove below
    body_json = {
        "prompt": f'{style_preset}-style image of {prompt}',
        "negative_prompt":negative_text,
        "mode": "text-to-image",
        "aspect_ratio": "4:5" if imagery_type == "feature_image" else "1:1",
        "seed": random.randint(0, 4294967295),
    }

    return json.dumps(body_json)
    
def save_image(table, assetId, assetPartId, partType,prompt,fullPrompt,original,thumbnail,bucket,key,assetType,style):
    """
    Adds images to the moodboard history table.
    """
    today = date.today()
    item = {
        "id":assetPartId,
        "moodboard_id":assetId,
        "fullPrompt":fullPrompt,
        "prompt":prompt,
        'generated_date':str(today),
        'base64':"",
        "original":original,
        "thumbnail":thumbnail,
        'part_type':partType,
        'bucket':bucket,
        'key':key,
        'assetType':assetType,
        'style':style

    }
    dynamo = boto3.resource('dynamodb').Table(table)
    #checking whether any record is exist or not
        #inserting the item from the responce
    res = dynamo.put_item(Item = item)
    if res["ResponseMetadata"]["HTTPStatusCode"] == 200 :
        result = "Success"
        msg = "Item created successfuly"
    else:
        result = "Failure"
        msg = "Failed to create Item"
    return item

def upload_image(region,data,file_name,bucket):
    try:
        extension = '.png'
        s3 = boto3.resource("s3")
        s3.Bucket(bucket).put_object(Key=file_name + extension, Body=data)
        url = create_presigned_url(region,bucket,file_name + extension,604800)
        return url
    except:
        print("The file couldn't be saved")
        return ''
    
def create_presigned_url(region,bucket_name, object_name, expiration=604800):
    s3_client = boto3.client('s3',region_name=region)
    try:
        print('generating presigned url')
        response = s3_client.generate_presigned_url('get_object',Params={'Bucket': bucket_name,'Key': object_name},ExpiresIn=expiration)
        print(response)
        return response
    except Exception as e:
        print(e)
        logging.error(e)
        return ""
    


def lambda_handler(event, context):
    region = context.invoked_function_arn.split(':')[3]
    acct = context.invoked_function_arn.split(':')[4]
    bucket = str(os.environ.get('ImageBucket')).rstrip().lstrip()
    table = os.environ.get('MoodboardHistoryTableName')
    lambda_client = boto3.client('lambda')
    lambdaToInvoke ='arn:aws:lambda:'+region+":"+acct+":function:"+str(os.environ.get('PublishResultsViaAppSyncLambda')).rstrip().lstrip()
    bedrock = boto3.client(service_name='bedrock-runtime', region_name=region, endpoint_url=f'https://bedrock-runtime.{region}.amazonaws.com')
    imageDescriptions = event["prompt"].split(';')
    imageDescription = imageDescriptions[0]
    assetId = event['assetId']
    assetPartId = event['assetPartId']
    partType = event['partType']
    style_preset ='photographic'
    if len(imageDescriptions)>1:
        style_preset = imageDescriptions[1]
    if "style" in event:
        style_preset = event["style"]
    date_created = time.strftime("%b %d %Y %H:%M:%S")
    assetType = 'moodboard'
    print('generating '+imageDescription+ ' at '+date_created)
    images = []
    new_image={
        'prompt':imageDescription,
        'assetId':assetId,
        'assetPartId':assetPartId,
        'date_created': date_created,
        'partType':partType,
        "original_width":"1024",
        "original_height":"1024px"
    }

    image_prompt =image_body(partType,imageDescription,style_preset)
    print("Prompt: ",image_prompt)
    try:
        response = bedrock.invoke_model(body=image_prompt, modelId='stability.sd3-large-v1:0', accept='application/json', contentType='application/json')
        response = json.loads(response.get('body').read())
        images = response.get('images')        
    except:
        print('Error creating image')
    if len(images)>0:
        imageb64 = images[0]
        img_data = imageb64.encode()
        image = base64.b64decode(img_data)
        key = (imageDescription.replace(' ','_')+"__"+assetId)    
        fileurl = upload_image(region,image,key,bucket)
        new_image['fullPrompt']=image_prompt
        new_image['prompt']=imageDescription
        new_image['original']=fileurl
        new_image['thumbnail']=fileurl
        new_image['partType']=partType
        
        dynamoDoc = save_image(table,assetId,assetPartId,partType,imageDescription,image_prompt,fileurl,fileurl,bucket,key+".png",assetType,style_preset)
        print(fileurl)
        
        payload = {
                    'id': assetId,
                    'content': json.dumps({"type":'regenerated_image',"results":new_image}),
                    'entities':json.dumps([imageDescription]),
                    'domain':'advertising-moodboard',
                    'prompt':imageDescription,
                    'source_type':'bedrock',
                    'source_id':'stability.sd3-large-v1:0'
        }
        lambda_payload = json.dumps(payload).encode('utf-8')
        lambda_client.invoke(FunctionName=lambdaToInvoke,
                                InvocationType='Event',
                                Payload=lambda_payload)
    
        return {
            'statusCode': 200,
            'body': payload
        }
    return {
        'statusCode':'-1',
        'body':{}
    }