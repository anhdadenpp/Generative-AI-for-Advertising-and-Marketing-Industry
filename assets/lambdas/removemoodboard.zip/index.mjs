import { QueryCommand, DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { unmarshall, convertToNative } from "@aws-sdk/util-dynamodb";
import {
  DynamoDBDocumentClient,
  BatchExecuteStatementCommand,
} from "@aws-sdk/lib-dynamodb";

export const handler = async (event, context) => {
  console.log(event);

  var table = process.env.MoodboardHistoryTableName;
  const client = new DynamoDBClient({});
  var docClient = DynamoDBDocumentClient.from(client);

  // const command = new DeleteItemCommand({
  //   TableName: table,
  //   "Key": {
  //     "moodboard_id": {
  //       "S": event["id"]
  //     }
  //   },
  // });
  const command = new QueryCommand({
    TableName: table,
    IndexName: 'moodboard_id-part_type-index',
    KeyConditionExpression: "moodboard_id = :moodboard_id",
    ExpressionAttributeValues: {
      ":moodboard_id": { S: event["moodboard_id"] },
    },
  });

  var moodboards = [];
  const response = await client.send(command);
  for (var i = 0; i < response.Items.length; i++) {
    var newItem = unmarshall(response.Items[i]);
    console.log("Deleting the moodboard parts.");
    const deleteItemStatementCommand = new BatchExecuteStatementCommand({
      // https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ql-reference.delete.html
      Statements: [
        {
          Statement: `DELETE FROM "${table}" WHERE "moodboard_id" = '${event["moodboard_id"]}' AND "id" = '${newItem.id}'`,
        },
      ],
    });
    var status = await docClient.send(deleteItemStatementCommand);
    console.log(JSON.stringify(status));
  }
  //const response = await client.send(command);
  return 200;
};
