import {SignatureV4} from '@aws-sdk/signature-v4';
import { HttpRequest } from '@aws-sdk/protocol-http';
import {defaultProvider} from "@aws-sdk/credential-provider-node";
import { Sha256 } from "@aws-crypto/sha256-js";

export const handler = async (event,context) => {
  event.user_input = "";
  event.domain = !event.domain?"advertising-moodboard":event.domain;
  event.source_type = !event.source_type?"Bedrock":event.source_type;
  event.source_id = !event.source_id?"":event.source_id;
  
  var appsyncInput = {
    id: event.Id?event.Id:event.id,
    entities: event.entities,
    prompt: event.prompt,
    source_type: event.source_type,
    content: event.content,
    domain: event.domain,
    source_id: event.source_id
  }
  const variables = {
    input: appsyncInput
  };
  console.log(`EVENT: ${JSON.stringify(event)}`);

  const endpoint = new URL(process.env.AppSyncAPI);
  var region = context.invokedFunctionArn.split(":")[3];
  const query = `mutation CreateGeneratedContentResults(
    $input: CreateGeneratedContentResultsInput!
  ) {
    createGeneratedContentResults(input: $input) {
      content
      domain
      entities
      id
      prompt
      source_id
      source_type
    }
  }`;
  const signer = new SignatureV4({
    credentials: defaultProvider(),
    region: region,
    service: 'appsync',
    sha256: Sha256
  });

  const requestToBeSigned = new HttpRequest({
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      host: endpoint.host,

    },
    hostname: endpoint.host,
    body: JSON.stringify({ query, variables }),
    path: endpoint.pathname
  });

  const signed = await signer.sign(requestToBeSigned);
  const request = new Request(process.env.AppSyncAPI, signed);

  let statusCode = 200;
  let body;
  let response;

  try {
    response = await fetch(request);
    console.log(request);
    body = await response.json();
    console.log(body);
    if (body.errors) {
      statusCode = 400;
      console.log(JSON.stringify(body.errors))
    }
  } catch (error) {
    console.log(JSON.stringify(error))
    statusCode = 500;
    body = {
      errors: [
        {
          message: error.message
        }
      ]
    };
  }

  return {
    statusCode,
    body: JSON.stringify(body)
  };
};