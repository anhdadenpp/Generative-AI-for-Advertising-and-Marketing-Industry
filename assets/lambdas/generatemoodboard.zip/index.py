import boto3
import json
import os
import uuid
from datetime import datetime, timezone

def add_moodboard(table_name, moodboard_id, adjectives, taglines, fonts, colors, pitch, prompt, spec, style, sounds, feature_image):
    """
    Adds a moodboard to the moodboard history table.
    """
    current_time = datetime.now(timezone.utc)
    
    item = {
        "id": uuid.uuid4().hex,
        "moodboard_id": moodboard_id,
        "adjectives": adjectives,
        "taglines": taglines,
        "fonts": fonts,
        "colors": colors,
        "pitch": pitch,
        "prompt": prompt,
        "generated_date": str(current_time),
        "spec": spec,
        "part_type": "data",
        "sounds": sounds,
        "style": style,
        "feature_image": feature_image
    }
    
    dynamo_table = boto3.resource("dynamodb").Table(table_name)
    
    response = dynamo_table.put_item(Item=item)
    if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
        print("Success: Item created successfully")
    else:
        print("Failure: Failed to create item")
    
    return item

def lambda_handler(event, context):
    print(event)
    result = event
    table_name = os.environ["MoodboardHistoryTableName"]
    region = os.environ["AWS_REGION"]
    account_id = context.invoked_function_arn.split(":")[4]
    user_input = event["user_input"]
    user_prompts = user_input.split("_")
    
    # Build the prompt
    prompt = f"In JSON format, please create a moodboard for an advertising campaign for {user_prompts[0]}"
    
    # Workshop task 1: Update the prompt
    prompt += (". Include a description for the feature image, a list of 4 colors, a list of 8 imagery descriptions, "
               "a list of 6 adjectives, and a list of 6 Google display fonts. "
               "Your response should be a parseable JSON object following this schema: \n"
               '<schema>{"feature_image": "string", "colors": "array","imagery": "array","adjectives": "array",'
               '"fonts": "array"}</schema>\n'
               "For each color, provide the websafe value. Do not include Roboto, Open Sans, Lato, Montserrat, "
               "or Raleway in your font suggestions. Do not use any form of the word 'child' in your imagery suggestions. "
               "Do not include any text in the response outside of the JSON object. Use double quotes for property names. "
               "Your response should consist of only the JSON data and not additional commentary as it will be used in downstream systems.")
    
    # Send the prompt through Bedrock
    print(f"Invoking model with prompt: {prompt}")
    bedrock = boto3.client(service_name="bedrock-runtime", region_name=region, endpoint_url=f"https://bedrock-runtime.{region}.amazonaws.com")

    # Workshop task 3: Modify the modelId
    model_id = "anthropic.claude-3-5-sonnet-20240620-v1:0"
    inference_config = {
        "maxTokens": 2048,
        "temperature": 1,
        "topP": 1
    }
    messages = [
        {
            "role": "user",
            "content": [
                {
                    "text": prompt 
                }
            ]
        }
    ]
    response = bedrock.converse(
        modelId=model_id,
        messages=messages,
        inferenceConfig=inference_config
    )
    string_answer = response["output"]["message"]["content"][0]["text"]
   
    # Extract and clean up JSON response
    json_start = string_answer.find("{")
    json_end = string_answer.rfind("}")
    if json_start != -1 and json_end != -1:
        string_answer = string_answer[json_start:json_end+1]
    
    try:
        structured_answer = json.loads(string_answer)
    except json.JSONDecodeError:
        # If parsing fails, attempt to clean up the JSON
        cleanup_prompt = f"Please clean up the JSON below so that it can be parsed. Ensure the property names are lowercased and trimmed, and return only the resulting JSON object. In your response, please do not include any text outside of the JSON object.\n{string_answer}"
        cleanup_messages = [
            {
                "role": "user",
                "content": [
                    {
                        "text": cleanup_prompt 
                    }
                ]
            }
        ]
        cleanup_response = bedrock.converse(
            modelId=model_id,
            messages=cleanup_messages,
            inferenceConfig=inference_config
        )
        cleanup_answer = cleanup_response["output"]["message"]["content"][0]["text"]
        structured_answer = json.loads(cleanup_answer)
    
    # Build the final result with the data returned from the Bedrock API call
    result.update({
        "pitch": structured_answer["pitch"] if "pitch" in structured_answer else '',
        "sounds": json.dumps([{"description": s, "clips": []} for s in structured_answer["sounds"]]) if "sounds" in structured_answer else "[]",
        "taglines": json.dumps(structured_answer["taglines"]) if "taglines" in structured_answer else '[]',
        "adjectives": json.dumps(structured_answer["adjectives"]),
        "colors": json.dumps(structured_answer["colors"]),
        "fonts": json.dumps(structured_answer["fonts"]),
        "imagery": json.dumps(structured_answer["imagery"]),
        "prompt": prompt,
        "feature_image": structured_answer["feature_image"],
        "style": "photographic" if len(user_prompts) == 1 else user_prompts[1]
    })
    
    # Insert the moodboard data into DynamoDB in the MoodboardHistory table
    add_moodboard(table_name, event["id"], result["adjectives"], result["taglines"],
                  result["fonts"], result["colors"], result["pitch"],
                  prompt, user_input, result["style"], result["sounds"], result["feature_image"])
    
    lambda_client = boto3.client("lambda")
    
    # Publish the data back to GraphQL API
    publish_lambda_arn = f"arn:aws:lambda:{region}:{account_id}:function:{os.environ.get('PublishResultsViaAppSyncLambda').strip()}"
    publish_payload = {
        "id": event["id"],
        "content": json.dumps({"type": "moodboard-data", "results": result}),
        "entities": json.dumps([]),
        "domain": "advertising-moodboard",
        "prompt": prompt,
        "source_type": "bedrock",
        "source_id": model_id
    }
    lambda_client.invoke(
        FunctionName=publish_lambda_arn,
        InvocationType="Event",
        Payload=json.dumps(publish_payload).encode("utf-8")
    )

    # Generate the feature image
    image_generation_lambda_arn = f"arn:aws:lambda:{region}:{account_id}:function:{os.environ.get('ImageGenerationLambda').strip()}"
    feature_image_payload = {
        "terms": [structured_answer["feature_image"]],
        "type": "feature-image",
        "id": event["id"],
        "spec": user_prompts[0],
        "style_preset": result["style"],
        "color_scheme": result["colors"]
    }
    lambda_client.invoke(
        FunctionName=image_generation_lambda_arn,
        InvocationType="Event",
        Payload=json.dumps(feature_image_payload).encode("utf-8")
    )
    
    # Generate the imagery
    for img in structured_answer["imagery"]:
        imagery_payload = {
            "terms": [img],
            "type": "imagery",
            "id": event["id"],
            "spec": user_prompts[0],
            "style_preset": result["style"],
            "color_scheme": result["colors"]
        }
        lambda_client.invoke(
            FunctionName=image_generation_lambda_arn,
            InvocationType="Event",
            Payload=json.dumps(imagery_payload).encode("utf-8")
        )

    return result