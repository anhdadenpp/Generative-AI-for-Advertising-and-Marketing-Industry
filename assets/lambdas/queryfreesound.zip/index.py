import json
import boto3
import freesound
import os
import time
import uuid;
from datetime import  date,datetime, time

def save_moodboard_sound(table, id, query,name, previews):
    """
    Adds sound effects to the moodboard history table.
    """
    today = date.today()
    item = {
        "id":uuid.uuid4().hex,
        "moodboard_id":id,
        "query":query,
        "name":name,
        "previews":json.dumps(previews),
        'part_type':"sounds"

    }
    dynamo = boto3.resource('dynamodb').Table(table)
    #checking whether any record is exist or not
        #inserting the item from the responce
    res = dynamo.put_item(Item = item)
    if res["ResponseMetadata"]["HTTPStatusCode"] == 200 :
        result = "Success"
        msg = "Item created successfuly"
    else:
        result = "Failure"
        msg = "Failed to create Item"
    return item

def lambda_handler(event, context):
    region = context.invoked_function_arn.split(':')[3]
    acct = context.invoked_function_arn.split(':')[4]
    
    client = freesound.FreesoundClient()
    client.set_token(os.environ.get("FreeSoundAPIKey").rstrip().lstrip())
    table = os.environ.get("MoodboardHistoryTableName").rstrip().lstrip()
    lambda_client = boto3.client('lambda')
    lambdaToInvoke ='arn:aws:lambda:'+region+":"+acct+":function:"+str(os.environ.get('PublishResultsViaAppSyncLambda')).rstrip().lstrip()
    terms = event['terms']
    for term in terms:
        resultObjects = []
    
        results = client.text_search(query=term,fields="id,name,previews")
        print(results)
        for result in results:
            resultjson = result.as_dict()
            resultjson['query'] = term
            print(resultjson)
            resultObjects.append(resultjson)
        
        save_moodboard_sound(table,event["id"],term,resultjson['name'],resultObjects)
        payload = {
                    'id': event['id'],
                    'content': json.dumps({"type":"sounds","query":term,"results":resultObjects}),
                    'entities':json.dumps(event['terms']),
                    'domain':'advertising-moodboard',
                    'prompt':term,
                    'source_type':'freesound',
                    'source_id':''
                }
        lambda_payload = json.dumps(payload).encode('utf-8')
        lambda_client.invoke(FunctionName=lambdaToInvoke,
                            InvocationType='Event',
                            Payload=lambda_payload)
        
            
        
    return {
        'statusCode': 200,
        'body': results
    }
